<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" href="favicon.svg" sizes="any" type="image/svg+xml">

    <?php if(!empty($siteConfiguration)): ?>
        <script>
            window.SiteConfiguration = <?php echo json_encode($siteConfiguration); ?>;
        </script>
    <?php endif; ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/scripts/app.tsx'); ?>

    <!-- Analytics -->
    <script defer data-domain="hosted.convoypanel.com"
            src="https://beacon.performave.com/js/script.local.js"></script>
    <script>
        window.plausible = window.plausible || function() {
            (window.plausible.q = window.plausible.q || []).push(arguments)
        }
    </script>
    <script>
        plausible('meta', {
            props: {
                version: '<?php echo e(config('app.version')); ?>',
            },
        })
    </script>
</head>
<body class="font-sans antialiased">
<div id="root"></div>
</body>
</html>
<?php /**PATH /var/www/resources/views/app.blade.php ENDPATH**/ ?>
<?php

namespace Convoy\Data\Server\Proxmox\Config;

use Spatie\LaravelData\Data;

class MediaData extends Data
{
    public function __construct(
        //
    )
    {
    }
}

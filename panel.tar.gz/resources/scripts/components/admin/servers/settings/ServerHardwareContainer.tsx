import ServerBuildSettingsCard from '@/components/admin/servers/settings/partials/hardware/ServerBuildSettingsCard'

const ServerHardwareContainer = () => {
    return (
        <>
            <ServerBuildSettingsCard />
        </>
    )
}

export default ServerHardwareContainer
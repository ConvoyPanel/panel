import AuthenticationCard from '@/components/servers/settings/partials/security/AuthenticationCard'

const SecurityContainer = () => {
    return (
        <>
            <AuthenticationCard />
        </>
    )
}

export default SecurityContainer
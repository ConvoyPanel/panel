import NameserversCard from '@/components/servers/settings/partials/network/NameserversCard'

const NetworkContainer = () => (
    <>
        <NameserversCard />
    </>
)

export default NetworkContainer
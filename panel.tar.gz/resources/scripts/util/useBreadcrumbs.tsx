const useBreadcrumbs = () => {}

export default useBreadcrumbs

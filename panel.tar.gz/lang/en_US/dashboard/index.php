<?php

return [
    'show_all_servers' => 'Show all servers',
    'no_servers_admin_empty_state' => 'There are no servers.',
    'no_servers_empty_state' => 'You have no servers.',
];

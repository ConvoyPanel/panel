<?php

return [
    'api' => [
        'resource_not_found' => 'The requested resource was not found on this server.',
    ],
];
<?php

return [
    'create_address' => 'Create Address',
    'create_modal' => [
        'title' => 'Create Address',
        'starting_address' => 'Starting Address',
        'ending_address' => 'Ending Address',
    ],
    'assigned_server' => 'Assigned Server',
    'edit_modal' => [
        'title' => 'Editing Address',
    ],
    'delete_modal' => [
        'title' => 'Delete Address?',
        'description' => 'Are you sure you want to delete :address?',
    ],
];
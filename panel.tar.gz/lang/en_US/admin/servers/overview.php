<?php

return [
  'enter_server_console' => 'Enter Server Console',
];
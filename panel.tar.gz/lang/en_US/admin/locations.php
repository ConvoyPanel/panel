<?php

return [
    'short_code' => 'Short Code',
    'create_location' => 'Create Location',
    'create_modal' => [
        'title' => 'Create a Location',
    ],
];

<?php

return [
    'create_modal' => [
        'title' => 'Create a Token',
    ],
    'created_modal' => [
        'title' => 'Token Created',
        'description' => 'Here is your newly created API token. Please take note of the token\'s value as this is the only and last time you will see it.',
        'button' => 'Okay, I copied it',
    ],
];

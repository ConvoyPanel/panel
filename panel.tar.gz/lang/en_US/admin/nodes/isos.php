<?php

return [
    'create_iso' => 'Create ISO',
    'checksum_algorithm' => 'Checksum Algorithm',
    'checksum' => 'Checksum',
    'create_modal' => [
        'title' => 'Create an ISO',
        'non_iso_file_name_error' => 'The file extension must end in .iso',
        'fail_to_query_remote_file_error' => 'Failed to query remote file.',
    ],
];